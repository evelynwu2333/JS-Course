// Performance Review
// 3 - superstar
// 2 - meets expectations
// 1 - needs improvement
// anything else - wtf?
let rating = 1;

if (rating === 3) {
	console.log('YOU ARE A SUPERSTAR!');
}
else if (rating === 2) {
	console.log('MEETS EXPECTATIONS');
}
else if (rating === 1) {
	console.log('NEEDS IMPROVEMENT');
}
