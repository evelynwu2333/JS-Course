// FALSY:
let loggedInUser = null;

// TRUTHY:
// let loggedInUser = 'Thomas123';

if (loggedInUser) {
	console.log('YOU ARE LOGGED IN!');
}
else {
	console.log('PLEASE LOG IN!');
}
