let age = 77;

if (age < 6 || age >= 65) {
	console.log('YOU GET IN FOR FREE');
}
else {
	console.log('YOU MUST PAYYYY!');
}

// EXAMPLE 2
// WE CAN USE MULTIPLE OR's:
let color = 'violet';
if (color === 'purple' || color === 'lilac' || color === 'violet') {
	console.log('GREAT CHOICE!');
}
