console.log(3 + 4, 'hello', true);
