// Example 1
if (1 === 1) {
	console.log("It's True!");
}

// Example 2
let rating = 3;

if (rating === 3) {
	console.log('YOU ARE A SUPERSTAR!');
}

// Example 3
let num = 37;

if (num % 2 !== 0) {
	console.log('ODD NUMBER!');
}
